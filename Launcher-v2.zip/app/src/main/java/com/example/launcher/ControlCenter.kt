package com.example.launcher

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

var torchOn = false

fun buildPanel(c: Context, dismiss: () -> Unit): View {
    val d = c.resources.displayMetrics.density
    fun dp(v: Int) = (v * d).toInt()
    val accent = P.accent(c)
    fun bg(col: Int, r: Int) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(col) }
    fun go(i: Intent) { dismiss(); c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun askWrite() = c.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun tile(icon: String, label: String, on: Boolean = false, tap: (View) -> Unit): View = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        background = bg(if (on) accent else 0x33FFFFFF, 22)
        layoutParams = GridLayout.LayoutParams().apply {
            width = 0; height = dp(70); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            setMargins(dp(4), dp(4), dp(4), dp(4))
        }
        addView(TextView(c).apply { text = icon; textSize = 22f; gravity = Gravity.CENTER })
        addView(TextView(c).apply { text = label; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        setOnClickListener { tap(it) }
    }

    fun slider(icon: String, max: Int, cur: Int, f: (Int) -> Unit): View = LinearLayout(c).apply {
        gravity = Gravity.CENTER_VERTICAL; background = bg(0x33FFFFFF, 18); setPadding(dp(14), dp(2), dp(14), dp(2))
        addView(TextView(c).apply { text = icon; textSize = 18f })
        addView(SeekBar(c).apply {
            this.max = max; progress = cur
            progressTintList = ColorStateList.valueOf(accent); thumbTintList = ColorStateList.valueOf(Color.WHITE)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { if (u) f(p) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    val grid = GridLayout(c).apply { columnCount = 4 }
    grid.addView(tile("📶", "Wi-Fi") { go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) })
    grid.addView(tile("🔵", "Bluetooth") { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) })
    grid.addView(tile("✈️", "Airplane") { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) })
    grid.addView(tile("🔦", "Torch", torchOn) { v ->
        val cm = c.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (id != null) { torchOn = !torchOn; cm.setTorchMode(id, torchOn); v.background = bg(if (torchOn) accent else 0x33FFFFFF, 22) }
    })
    grid.addView(tile("🔄", "Rotate") {
        if (Settings.System.canWrite(c)) {
            val cur = Settings.System.getInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
            Settings.System.putInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1 - cur)
            Toast.makeText(c, if (cur == 1) "Rotation locked" else "Auto-rotate on", Toast.LENGTH_SHORT).show()
        } else askWrite()
    })
    grid.addView(tile("🔒", "Lock") { dismiss(); c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
    grid.addView(tile("📷", "Camera") { go(Intent(MediaStore.ACTION_IMAGE_CAPTURE)) })
    grid.addView(tile("⚙️", "Settings") { go(Intent(Settings.ACTION_SETTINGS)) })

    val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val gap = { LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) } }
    return LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(12), dp(10), dp(12)); isClickable = true
        background = bg(0xEE141824.toInt(), 30)
        addView(grid)
        addView(slider("☀️", 255, Settings.System.getInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)) { p ->
            if (Settings.System.canWrite(c)) {
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, p.coerceAtLeast(1))
            } else askWrite()
        }, gap())
        addView(slider("🔊", am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), am.getStreamVolume(AudioManager.STREAM_MUSIC)) {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0)
        }, gap())
    }
}

class ControlCenter(private val a: Activity) : Dialog(a, android.R.style.Theme_Translucent_NoTitleBar) {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val m = (10 * a.resources.displayMetrics.density).toInt()
        setContentView(FrameLayout(a).apply {
            setBackgroundColor(0x88000000.toInt()); setOnClickListener { dismiss() }
            addView(buildPanel(a) { dismiss() }, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { setMargins(m, m * 4, m, 0) })
        })
        window?.setLayout(-1, -1)
    }
}
