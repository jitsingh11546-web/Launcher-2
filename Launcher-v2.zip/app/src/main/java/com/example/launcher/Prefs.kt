package com.example.launcher

import android.content.Context

object P {
    val themes = listOf("Ocean" to 0xFF3D6BFF.toInt(), "Mint" to 0xFF1D9E75.toInt(), "Sunset" to 0xFFD85A30.toInt(), "Grape" to 0xFF7F77DD.toInt())
    fun sp(c: Context) = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    fun accent(c: Context) = themes[sp(c).getInt("theme", 0)].second
    fun get(c: Context, k: String): MutableList<String> =
        (sp(c).getString(k, "") ?: "").split("|").filter { it.isNotEmpty() }.toMutableList()
    fun put(c: Context, k: String, v: List<String>) = sp(c).edit().putString(k, v.joinToString("|")).apply()
}
